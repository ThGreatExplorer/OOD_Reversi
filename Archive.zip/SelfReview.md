## Self Review

### Reflect on our design
- What do you wish you had done differently in your design/implementation? Did you learn any 
lessons from the code given to you, or the updates you had to make for your customers?


It was very interesting to first-hand experience the process of using and integrating code we had
never touched before, and to be on both sides of the equation. We definitely learned the importance
of having very clear and detailed documentation, so that someone can understand the ins and outs
of you code without needing to read through every line.

### Interactions with providers
Our providers were lovely to work with. They had quick responses and were very helpful. They were
very knowledgeable about their code and knew the flaws and kinks it had.
